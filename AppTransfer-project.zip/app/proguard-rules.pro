# AppTransfer currently does not require custom ProGuard rules.
