package com.michaeltoni0412.apptransfer

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: AppAdapter
    private lateinit var progress: ProgressBar
    private val executor = Executors.newSingleThreadExecutor()
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progress = findViewById(R.id.progress)
        val list = findViewById<RecyclerView>(R.id.app_list)
        val search = findViewById<EditText>(R.id.search)

        adapter = AppAdapter { app -> exportApk(app) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        search.addTextChangedListener(SimpleTextWatcher { text ->
            val query = text.trim().lowercase(Locale.getDefault())
            adapter.submitList(
                if (query.isEmpty()) allApps else allApps.filter {
                    it.name.lowercase(Locale.getDefault()).contains(query) ||
                    it.packageName.lowercase(Locale.getDefault()).contains(query)
                }
            )
        })

        loadApps()
    }

    private fun loadApps() {
        progress.visibility = ProgressBar.VISIBLE
        executor.execute {
            val pm = packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .filter { it.packageName != packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .map {
                    AppInfo(
                        name = pm.getApplicationLabel(it).toString(),
                        packageName = it.packageName,
                        sourcePath = it.sourceDir,
                        icon = it.loadIcon(pm)
                    )
                }
                .sortedBy { it.name.lowercase(Locale.getDefault()) }

            runOnUiThread {
                allApps = apps
                adapter.submitList(apps)
                progress.visibility = ProgressBar.GONE
            }
        }
    }

    private fun exportApk(app: AppInfo) {
        progress.visibility = ProgressBar.VISIBLE
        executor.execute {
            try {
                val folder = File(filesDir, "apks").apply { mkdirs() }
                val safeName = app.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val destination = File(folder, "$safeName.apk")

                FileInputStream(File(app.sourcePath)).use { input ->
                    FileOutputStream(destination).use { output ->
                        input.copyTo(output, 1024 * 1024)
                    }
                }

                runOnUiThread {
                    progress.visibility = ProgressBar.GONE
                    Toast.makeText(this, "APK saved: ${destination.name}", Toast.LENGTH_SHORT).show()
                    shareApk(destination)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = ProgressBar.GONE
                    Toast.makeText(
                        this,
                        "Could not export this app: ${e.message ?: "unknown error"}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun shareApk(file: File) {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Send APK"))
    }

    fun installApk(file: File) {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}

data class AppInfo(
    val name: String,
    val packageName: String,
    val sourcePath: String,
    val icon: android.graphics.drawable.Drawable
)
