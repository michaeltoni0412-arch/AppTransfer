package com.michaeltoni0412.apptransfer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onExport: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.Holder>() {
    private var apps: List<AppInfo> = emptyList()

    fun submitList(newApps: List<AppInfo>) {
        apps = newApps
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(apps[position])
    override fun getItemCount() = apps.size

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val icon: ImageView = view.findViewById(R.id.icon)
        private val name: TextView = view.findViewById(R.id.name)
        private val packageName: TextView = view.findViewById(R.id.package_name)
        private val export: Button = view.findViewById(R.id.export_button)

        fun bind(app: AppInfo) {
            icon.setImageDrawable(app.icon)
            name.text = app.name
            packageName.text = app.packageName
            export.setOnClickListener { onExport(app) }
        }
    }
}
